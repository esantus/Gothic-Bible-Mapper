import string
import re
import pdb


langs = ['Skt', 'OIr', 'OGer', 'Eng', 'Dut', 'Ger', 'English', 'Rus', 'VLat', 'OCS', 'ON', 'OEng', 'Gre', 'Swe', 'OHGer', 'Icl', 'Lat', 'Russian']


def get_voc(fname='gothic_dict.txt'):
	voc = {}
	for line in open(fname, 'r'):
		line = re.sub(r"[\[,.;@#?!&$\]]+\ *", ' ', line)
		line = line.split()

		if len(line) < 2:
			continue

		if line[0] not in voc:
			voc[line[0]] = {}

		if 'akin' in line:
			idx = line.index('akin')

			if not line[idx+2][0].isupper() or line[idx+2].startswith('Comp'):
				continue

			idx += 2
			while line[idx] != ':' and idx < len(line)-1:
				if line[idx] in langs:
					if line[idx] == 'Russian':
						line[idx] = 'Rus'
					if line[idx] == 'English':
						line[idx] = 'Eng'
					voc[line[0]][line[idx]] = line[idx+1]
				idx += 1

	return { k:voc[k] for k in voc if len(voc[k])>0 }