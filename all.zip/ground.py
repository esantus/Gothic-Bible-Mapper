import os, sys
from cube.api import Cube
from gothic_ipa import ipa_transformer, gothic_script_transformer
from clean_dict import get_voc
import pickle
import re

import pdb


# Analysis fields
index = 0
word = 1
lemma = 2
upos = 3
xpos = 4
attrs = 5
head = 6
label = 7
deps = 8
space_after = 9




def load_bible(f):
	bible = {}
	text = 0
	for l in f:
		l = l.strip().split('\t')
		
		if text == 0 and 'orig_chapter' not in l: # Not yet column titles
			continue
		elif 'orig_chapter' in l: # Saving the columns
			book = l.index('orig_book_index')-1
			chapter = l.index('orig_chapter')-1
			verse = l.index('orig_verse')-1
			try:
				subverse = l.index('orig_subverse')-1
			except:
				pass
			text = l.index('text')-1
			continue

		if len(l) >= text+1: # Saving the dictionary
			if l[book] not in bible:
				bible[l[book]] = {}	
			if l[chapter] not in bible[l[book]]:
				bible[l[book]][l[chapter]] = {}
			bible[l[book]][l[chapter]][l[verse]] = l[text]
	return bible



def analyze(text, cube, lang='got'):
	sentences=cube(text)

	analysis = []
	if type(sentences[0]) == list:
		for sentence in sentences:
			for token in sentence:
				#index, word, lemma, upos, xpos, attrs, head, label, deps, space_after
				analysis.append([token.index, token.word, token.lemma, token.upos, token.xpos, token.head, token.label, token.deps, token.space_after])
	else:
		for token in sentences:
				#index, word, lemma, upos, xpos, attrs, head, label, deps, space_after
				analysis.append([token.index, token.word, token.lemma, token.upos, token.xpos, token.head, token.label, token.deps, token.space_after])

	return analysis



def fake_analyze(text, cube, lang='got'):
	line = re.sub(r"[\[,.;@#?!&$\]]+\ *", ' ', text)

	analysis = []
	for token in line.split():
		#index, word, lemma, upos, xpos, attrs, head, label, deps, space_after
		analysis.append(['_', '_', token, '_', '_', '_', '_', '_', '_'])
	
	return analysis



def map_bibles(f1, f2, voc, l1='gothic', l2='greek', cube1=True, cube2=True):
	f1_dict = load_bible(f1)
	f2_dict = load_bible(f2)

	lemma_l1 = False if cube1 == False else True
	lemma_l2 = False if cube2 == False else True


	count = 0
	mapped = {}
	for book in f1_dict:
		if book in f2_dict:
			if book not in mapped:
				mapped[book] = {}
			for chapter in f1_dict[book]:
				if chapter in f2_dict[book]:
					if chapter not in mapped[book]:
						mapped[book][chapter] = {}
					for verse in f1_dict[book][chapter]:
						if verse in f2_dict[book][chapter]:
							if verse not in mapped[book][chapter]:
								mapped[book][chapter][verse] = {}

							if count % 100 == 0:
								print(count)
								#pdb.set_trace()
							count += 1

							mapped[book][chapter][verse][l1] = f1_dict[book][chapter][verse]
							if lemma_l1:
								mapped[book][chapter][verse][l1+'_analyzed'] = analyze(f1_dict[book][chapter][verse], cube1)
							else:
								mapped[book][chapter][verse][l1+'_analyzed'] = fake_analyze(f1_dict[book][chapter][verse], cube1)
							
							if l1 == 'got':
								mapped[book][chapter][verse][l1+'_original'] = gothic_script_transformer(f1_dict[book][chapter][verse])
								mapped[book][chapter][verse][l1+'_ipa'] = ipa_transformer(f1_dict[book][chapter][verse], 'gothic')

								lemmas = list(list(zip(*mapped[book][chapter][verse][l1+'_analyzed']))[2])
								mapped[book][chapter][verse][l1+'_lemma'] = lemmas
								mapped[book][chapter][verse][l1+'_translation'] = {}
								for lang in ['Skt', 'OIr', 'OGer', 'Eng', 'Dut', 'Ger', 'English', 'Rus', 'VLat', 'OCS', 'ON', 'OEng', 'Gre', 'Swe', 'OHGer', 'Icl', 'Lat', 'Russian']:
									if lang not in mapped[book][chapter][verse][l1+'_translation']:
										mapped[book][chapter][verse][l1+'_translation'][lang] = []

									for word in lemmas:
										#print(word)
										if word in voc and lang in voc[word]:
											mapped[book][chapter][verse][l1+'_translation'][lang].append(voc[word][lang])
										else:
											mapped[book][chapter][verse][l1+'_translation'][lang].append('_')

							mapped[book][chapter][verse][l2] = f2_dict[book][chapter][verse]
							if lemma_l2:
								mapped[book][chapter][verse][l2+'_analyzed'] = analyze(f2_dict[book][chapter][verse], cube2)
							else:
								mapped[book][chapter][verse][l2+'_analyzed'] = fake_analyze(f2_dict[book][chapter][verse], cube2)

							if l2 =='grc':
								mapped[book][chapter][verse][l2+'_ipa'] = ipa_transformer(f2_dict[book][chapter][verse], 'greek')
	return mapped





if __name__ == "__main__":
	#try:
	if True:
		lang_file = {'gothic':'gothic/gothic_latin_utf8.txt', 'latin':'latin/latin_vulgata_clementina_utf8.txt', 'italian':'italian/italian_riveduta_1927_utf8.txt',
					 'german':'german/german_luther_1912_utf8.txt'}
		lang_acron = {'gothic':'got', 'latin':'la', 'italian':'it', 'german':'de'}

		lang1 = sys.argv[1]
		lang2 = sys.argv[2]

		try:
			analysis = False if sys.argv[3] == 'False' else True
		except:
			analysis = True

		if os.path.isfile(lang_file[lang1]) and os.path.isfile(lang_file[lang2]):
			with open(lang_file[lang1], 'r') as lang1_f:
				with open(lang_file[lang2], 'r') as lang2_f:
					if analysis:
						cube1=Cube(verbose=False)
						cube1.load(lang_acron[lang1])

						cube2=Cube(verbose=False)
						cube2.load(lang_acron[lang2])
					else:
						cube1 = cube2 = False

					voc = get_voc('gothic_dict.txt')
					mapped = map_bibles(lang1_f, lang2_f, voc, lang_acron[lang1], lang_acron[lang2], cube1, cube2)

					pickle.dump(mapped, open('{}_{}.p'.format(lang_acron[lang1], lang_acron[lang2]), 'wb'))


					pdb.set_trace()
			print('Finished')

		else:
			print('Error opening the files. Call:\n\n\tpython ground.py gothic_fname other_fname\n')
	#except Exception as e:
	#	print('Error: {}'.format(e))
	#	print('It is possible you have not provided the file names. Call:\n\n\tpython ground.py gothic_fname other_fname\n')

	# Initialize the lemmatizer before to avoid doing it all the times.
	#for x in lemmatize(text="jah in dagam jainaim", lang=got):
	#	print(x)